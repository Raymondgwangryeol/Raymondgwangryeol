﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class Form2 : Form
    {
        Form1 form1; // Form1의 데이터를 가져와야 하므로 인스턴스 생성

        public Form2(Form1 form) 
        {
            InitializeComponent();
            form1 = form; //내가 만든 그 'Form1'을 집어넣음
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void IdIs_Click(object sender, EventArgs e)
        {

        }

        private void Welcome_Click(object sender, EventArgs e)
        {

        }
        public void SetText(string data)
        {
            label2.Text = data; // Form2 에서 아이디가 출력되는 곳. Form1에서 가져와(string data) 여기다 뿌림.
        }
    }
}
