﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game
{
    public partial class Form1 : Form
    {
        private int findNumber = 0;
        private int chance = 0;
        public static int NUM()
        {
            return 10;
        } // static class constant{}로 못 함. 왜지? 그래서 그냥 static 함수로 처리함.

        public void again() 
        {
            //태초마을로 가는 건 싫어서 시작 버튼 클릭하면 무한으로 즐겨요 명륜진사갈비 할 수 있게 함.
            ButtonStart.Text = "다시 시작";
            //초기화 작업
            chance = NUM();
            TextBox.Enabled = false;
            ButtonInput.Enabled = false;
        }
        public Form1()
        {
            InitializeComponent();

            //시작 하기도 전에 Enabled 되어있는 거 거슬려서 그냥 함.
            TextBox.Enabled = false;
            ButtonInput.Enabled = false;
        }
        public void ButtonStart_Click(object sender, EventArgs e)
        {
            TextBox.Text=null; //이게 되냐????
            var rand = new Random(); //랜덤 변수 생성
            findNumber = rand.Next(1,21); // .Next는 임의의 양의 정수를 반환.()에 int minValue, maxValue해서 min~max사이의 랜덤한 수를 뽑아낼 수도 있음
            chance = NUM();

            TextBox.Enabled = true;
            ButtonInput.Enabled = true;

            display.Text = "정답을 입력해 주세요";
        }
        //놀라운 사실: textbox에 입력하고 버튼을 눌러 가져오면 된다.
        //더 놀라운 사실: 나는 readwrite로 받으려고 하고 있었다. 왜 그랬냐 아


        public void Input_Click(object sender, EventArgs e)
        // 헐... 자연스럽게 반복문 돌리고 있었네 미친
        {
            int answer= -1;
            answer = Convert.ToInt32(TextBox.Text);//string을 int로 바꿀 땐 Convert.ToInt32()

            if (answer == findNumber)
            {
                display.Text = "정답입니다";
                again();
            }
            else
            {
             chance--;
                if (chance == 0)
                {
                    display.Text = "답은" + findNumber + "입니다";
                    again();
                }
                else display.Text = "오답. 남은 기회 " + chance.ToString() + "번";
                
            }
        }
    }
}
